# pybashrc
Automatically register python functions as bash commands

TODO:
- [ ] Write a proper readme
- [ ] Print function info if we get a TypeError when calling it
- [ ] Support click commands
- [ ] Support running from a virtual environment?
